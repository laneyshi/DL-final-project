figure()
Device=[2,3,4];              %����ϵͳ���ܵĻ���ռ�ΪCahce���ļ�
%numRRH=4,numfile=4
energy=[0.6857047353511789   0.6676155653280037    0.6857047353511789;
        1.2283593333813732   1.2432645630640726    1.4340489404202585;
        1.5112857804354725   1.581362404560163    2.363305853792754];
%%
%Set the size of the figure
set(gcf,'Position',[-50,-50,1050,700]);
set(gca,'fontname','Times New Roman','Color','k','FontSize',10,'LineWidth',1);

%%
%��ͼ%
h=bar(Device,energy);
%[0.7 0.7 0.7] is grey, [ 0.05 .45 0.1] is green
% barmap=[0.13333, 0.5451, 0.13333; 0.2549, 0.41176, 0.88235; 0.69804, 0.13333, 0.13333];
% c = colormap(barmap);
% set(h(1),'FaceColor',[0.13333, 0.5451, 0.13333]);
% set(h(2),'FaceColor',[0.2549, 0.41176, 0.88235]);
% set(h(3),'FaceColor',[0.69804, 0.13333, 0.13333]);
ylim([0 3])
grid on
%legend('Heuristic algorithm','Enumeration algorithm'); 
legend({'2CUs and 2EUs','3CUs and 3EUs','4CUs and 4EUs'},'FontName','Times New Roman', 'FontSize', 12, 'Location', 'NorthEast');
xlabel('Number of APs', 'FontName','Times New Roman', 'FontSize', 13);
ylabel('Average System Energy Consumption (mJ)', 'FontName','Times New Roman', 'FontSize', 13);
applyhatch(gcf, '\.x')

% figure()
% Device=[2,3,4];              %����ϵͳ���ܵĻ���ռ�ΪCahce���ļ�
% %numRRH=4,numfile=4
reward=[-8.603350404963452   -10.27907335141567    -22.03342724924559;
        -9.324370384873145   -15.42554772055869    -29.708505548354047;
        -10.859322157427032   -20.29436387361814    -37.42291834265821];
% 
% %%
% %Set the size of the figure
% set(gcf,'Position',[100,60,420,280]);
% set(gca,'fontname','Times New Roman','Color','k','FontSize',10,'LineWidth',1);
% 
% %%
% %��ͼ%
% h=bar(Device,reward);
%  %[0.7 0.7 0.7] is grey, [ 0.05 .45 0.1] is green
% set(h(1),'FaceColor',[0.13333, 0.5451, 0.13333]);
% set(h(2),'FaceColor',[0.2549, 0.41176, 0.88235]);
% set(h(3),'FaceColor',[0.69804, 0.13333, 0.13333]);
% % ylim([0 4])
% grid on
% %legend('Heuristic algorithm','Enumeration algorithm'); 
% legend({'2CUs and 2EUs','3CUs and 3EUs','4CUs and 4EUs'},'FontName','Times New Roman', 'FontSize', 10, 'Location', 'SouthWest');
% xlabel('Number of APs', 'FontName','Times New Roman', 'FontSize', 9);
% ylabel('Average Reward', 'FontName','Times New Roman', 'FontSize', 9);

figure()
Device=[2,3,4];              %����ϵͳ���ܵĻ���ռ�ΪCahce���ļ�
%numRRH=4,numfile=4
% reward_per_energy= reward./energy;
reward_per_energy = reward;
%%
%Set the size of the figure
set(gcf,'Position',[100,60,420,280]);
set(gca,'fontname','Times New Roman','Color','k','FontSize',10,'LineWidth',1);

%%
%��ͼ%
h=bar(Device,reward_per_energy);
h=bar(Device,reward);
 %[0.7 0.7 0.7] is grey, [ 0.05 .45 0.1] is green
set(h(1),'FaceColor',[0.13333, 0.5451, 0.13333]);
set(h(2),'FaceColor',[0.2549, 0.41176, 0.88235]);
set(h(3),'FaceColor',[0.69804, 0.13333, 0.13333]);
% ylim([0 4])
grid on
%legend('Heuristic algorithm','Enumeration algorithm'); 
legend({'2CUs and 2EUs','3CUs and 3EUs','4CUs and 4EUs'},'FontName','Times New Roman', 'FontSize', 10, 'Location', 'SouthEast');
xlabel('Number of APs', 'FontName','Times New Roman', 'FontSize', 9);
ylabel('Average Energy Efficiency', 'FontName','Times New Roman', 'FontSize', 9);
