clear all
%% Load the data
load('..\..\plot_data\dt\compare_update.mat')

%%
figure()
set(gcf,'Position',[100,40,420,280]);

beam0 = plot(x, PDQN_Beam_b, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
beam0.Color(4) = alpha;
hold on;
beam1 = plot(x, DPDQN_Beam_b, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
beam1.Color(4) = alpha;
hold on;
beam2 = plot(x, DTPDQN_Beam_b, 'Color', [0.6980, 0.1333, 0.1333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
beam2.Color(4) = alpha;
hold on;
beam3 = plot(x, DTDPDQN_Beam_b, 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
beam3.Color(4) = alpha;
hold on;

Beam0 = plot(x, PDQN_Beam, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Beam1 = plot(x, DPDQN_Beam, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Beam2 = plot(x, DTPDQN_Beam, 'Color', [0.6980, 0.1333, 0.1333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Beam3 = plot(x, DTDPDQN_Beam, 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;

ylim([0.3 1.2])
xlim([0 400])

set(gca,'fontname','Times New Roman','FontSize',9);

grid on
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 9);
ylabel('Average Correlation Coefficient ', 'FontName', 'Times New Roman', 'FontSize', 9);
legend([Beam0 Beam1 Beam2 Beam3],{'P-DQN Beam', 'DP-DQN Beam', 'P-DQN with DT Beam', 'DP-DQN with DT Beam'},...
    'FontName', 'Times New Roman', 'FontSize', 10); 

figure()
set(gcf,'Position',[100,40,420,280]);

classification0 = plot(x, PDQN_Classification_b, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
classification0.Color(4) = alpha;
hold on;
classification1 = plot(x, DPDQN_Classification_b, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
classification1.Color(4) = alpha;
hold on;
classification2 = plot(x, DTPDQN_Classification_b, 'Color', [0.6980, 0.1333, 0.1333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
classification2.Color(4) = alpha;
hold on;
classification3 = plot(x, DTDPDQN_Classification_b, 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
classification3.Color(4) = alpha;
hold on;

PDQN_Classification(PDQN_Classification<=0) = 0;
DPDQN_Classification(DPDQN_Classification<=0) = 0;
DTPDQN_Classification(DTPDQN_Classification<=0) = 0;
DTDPDQN_Classification(DTDPDQN_Classification<=0) = 0;

Classification0 = plot(x, PDQN_Classification, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Classification1 = plot(x, DPDQN_Classification, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Classification2 = plot(x, DTPDQN_Classification, 'Color', [0.6980, 0.1333, 0.1333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Classification3 = plot(x, DTDPDQN_Classification, 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
grid on

ylim([-0.1 1.1])
xlim([0 400])

set(gca,'fontname','Times New Roman','FontSize',9);

xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 9);
ylabel('Average Update in One Transmission Frame', 'FontName', 'Times New Roman', 'FontSize', 9);
legend([Classification0 Classification1 Classification2 Classification3],...
    {'P-DQN Classification',  'DP-DQN Classification', 'P-DQN with DT Classification' 'DP-DQN with DT Classification'},...
    'FontName', 'Times New Roman', 'FontSize', 10); 

