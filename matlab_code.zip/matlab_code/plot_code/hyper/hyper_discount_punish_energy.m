clear all
%% Load the data
load('..\..\plot_data\hyper\\hyper_discount_system_energy.mat')
legend_index = strings(1,length(discount));
for i = 1:length(discount)
    legend_index(i) = num2str(discount(i));
end
%%

figure()
set(gcf,'Position',[100,40,420,280]);

discount0 = plot(x, Discount0, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
discount0.Color(4) = alpha;
hold on;
discount1 = plot(x, Discount1, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
discount1.Color(4) = alpha;
hold on;
discoune2 = plot(x, Discount2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
discoune2.Color(4) = alpha;
hold on;
discount3 = plot(x, Discount3, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
discount3.Color(4) = alpha;
hold on;
hold on

energy0 = plot(x, Energy0, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
hold on;
energy1 = plot(x, Energy1, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
hold on;
energy2 = plot(x, Energy2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
hold on;
energy3 = plot(x, Energy3, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
hold on;
grid on

ylim([0 3])
xlim([0 400])

set(gca,'fontname','Times New Roman','FontSize',9);
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 9);
ylabel('Network Energy Consumption (mJ/frame)', 'FontName', 'Times New Roman', 'FontSize', 9);
h=legend([energy0 energy1 energy2 energy3], ...
    {['$$\gamma$$ = ' ,char(legend_index(1))], ['$$\gamma$$ = ',char(legend_index(2))], ['$$\gamma$$ = ',char(legend_index(3))], ...
    ['$$\gamma$$ = ',char(legend_index(4))]},...
    'FontName', 'Times New Roman', 'FontSize', 10,'interpreter','latex','Location','southeast'); 
set(h,'FontName','Times New Roman','FontSize',10,'FontWeight','normal')

load('..\..\plot_data\hyper\hyper_discount_punish.mat')
% load('C:/Users/52394/Desktop/Paper-Template-DRL/py_code/pythonProject/matlab_code/hyper_discount_cons.mat')

figure()
set(gcf,'Position',[100,40,420,280]);

discount0 = plot(x, Discount0, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
discount0.Color(4) = alpha;
hold on;
discount1 = plot(x, Discount1, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
discount1.Color(4) = alpha;
hold on;
discoune2 = plot(x, Discount2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
discoune2.Color(4) = alpha;
hold on;
discount3 = plot(x, Discount3, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
discount3.Color(4) = alpha;
hold on

% cons0 = plot(x, Cons0, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
% hold on;
% cons1 = plot(x, Cons1, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
% hold on;
% cons2 = plot(x, Cons2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
% hold on;
% cons3 = plot(x, Cons3, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
% hold on;
% cons4 = plot(x, Cons4, 'Color', [0.54118, 0.16863, 0.88627], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
% hold on;
% cons5 = plot(x, Cons5, 'Color', [0, 0, 0], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
% hold on;
% grid on
% 
% xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 14);
% ylabel('Average Reward', 'FontName', 'Times New Roman', 'FontSize', 14);
% h=legend([cons0 cons1 cons2 cons3 cons4 cons5], ...
%     {['Discount = ',char(legend_index(1))], ['Discount = ',char(legend_index(2))], ['Discount = ',char(legend_index(3))], ...
%     ['Discount = ',char(legend_index(4))], ['Discount = ',char(legend_index(5))], ['Discount = ',char(legend_index(6))]},...
%     'FontName', 'Times New Roman', 'FontSize', 12); 
% set(h,'FontName','Times New Roman','FontSize',9,'FontWeight','normal')

reward0 = plot(x, Reward0, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
hold on;
reward1 = plot(x, Reward1, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
hold on;
reward2 = plot(x, Reward2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
hold on;
reward3 = plot(x, Reward3, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
hold on;
grid on

% ylim([-70 50])
xlim([0 400])

set(gca,'fontname','Times New Roman','FontSize',9);
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 9);
ylabel('Average Reward', 'FontName', 'Times New Roman', 'FontSize', 9);
h=legend([reward0 reward1 reward2 reward3], ...
    {['$$\gamma$$ = ' ,char(legend_index(1))], ['$$\gamma$$ = ',char(legend_index(2))], ['$$\gamma$$ = ',char(legend_index(3))], ...
    ['$$\gamma$$ = ',char(legend_index(4))]},...
    'FontName', 'Times New Roman', 'FontSize', 10,'interpreter','latex','Location','southeast'); 
set(h,'FontName','Times New Roman','FontSize',10,'FontWeight','normal')


% subplot(titleA);
% set(titleA,'Visible','off');
% axis([0 1 0 1]);
% text(0.48,0.95, '(a)', 'FontName', 'Times New Roman', 'FontSize',9);
% 
% subplot(titleB);
% set(titleB,'Visible','off');
% axis([0 1 0 1]);
% text(0.41,0.95, '(b)', 'FontName', 'Times New Roman', 'FontSize',9);
% Plot all fixed positions
