clear all
%% Load the data
load('..\..\plot_data\hyper\hyper_replace_system_energy.mat')

legend_index = strings(1,length(softreplace));
for i = 1:length(softreplace)
    legend_index(i) = num2str(softreplace(i));
end
%%
figure()
set(gcf,'Position',[100,40,420,280]);

replacement0 = plot(x, Replacement0, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
replacement0.Color(4) = alpha;
hold on;
replacement1 = plot(x, Replacement1, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1, 'Markersize', 10);
replacement1.Color(4) = alpha;
hold on;
replacement2 = plot(x, Replacement2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1, 'Markersize', 10);
replacement2.Color(4) = alpha;
hold on;
replacement3 = plot(x, Replacement3, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-.', 'LineWidth',1, 'Markersize', 10);
replacement3.Color(4) = alpha;
hold on

energy0 = plot(x, Energy0, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
energy1 = plot(x, Energy1, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
energy2 = plot(x, Energy2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1.75, 'Markersize', 10);
hold on;
energy3 = plot(x, Energy3, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-.', 'LineWidth',1.75, 'Markersize', 10);
hold on;
grid on

ylim([0 2.5])
xlim([0 400])

set(gca,'fontname','Times New Roman','FontSize',10);
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('Network Energy Consumption (mJ/frame)', 'FontName', 'Times New Roman', 'FontSize', 11);
h = legend([energy0 energy1 energy2 energy3], ...
    {['$$\tau$$ = ',char(legend_index(1))], ['$$\tau$$ = ',char(legend_index(2))], ['$$\tau$$ = ',char(legend_index(3))], ...
    ['$$\tau$$ = ',char(legend_index(4))]},...
    'FontName', 'Times New Roman', 'FontSize', 10 ,'interpreter','latex','Location','southeast'); 
set(h,'FontName','Times New Roman','FontSize',10,'FontWeight','normal')

load('..\..\plot_data\hyper\hyper_replace_punish.mat')

figure()
set(gcf,'Position',[100,40,420,280]);

replacement0 = plot(x, Discount0, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
replacement0.Color(4) = alpha;
hold on;
replacement1 = plot(x, Discount1, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1, 'Markersize', 10);
replacement1.Color(4) = alpha;
hold on;
replacement2 = plot(x, Discount2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1, 'Markersize', 10);
replacement2.Color(4) = alpha;
hold on;
replacement3 = plot(x, Discount3, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-.', 'LineWidth',1, 'Markersize', 10);
replacement3.Color(4) = alpha;
hold on;

reward0 = plot(x, Reward0, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
reward1 = plot(x, Reward1, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
reward2 = plot(x, Reward2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1.75, 'Markersize', 10);
hold on;
reward3 = plot(x, Reward3, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-.', 'LineWidth',1.75, 'Markersize', 10);
hold on;

xlim([0 400])

grid on
set(gca,'fontname','Times New Roman','FontSize',10);
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('Average Reward', 'FontName', 'Times New Roman', 'FontSize', 11);
h = legend([reward0 reward1 reward2 reward3], ...
    {['$$\tau$$ = ',char(legend_index(1))], ['$$\tau$$ = ',char(legend_index(2))], ['$$\tau$$ = ',char(legend_index(3))], ...
    ['$$\tau$$ = ',char(legend_index(4))]},...
    'FontName', 'Times New Roman', 'FontSize', 10,'interpreter','latex','Location','southeast'); 
set(h,'FontName','Times New Roman','FontSize',10,'FontWeight','normal')

% subplot(titleA);
% set(titleA,'Visible','off');
% axis([0 1 0 1]);
% text(0.48,0.95, '(a)', 'FontName', 'Times New Roman', 'FontSize',9);
% 
% subplot(titleB);
% set(titleB,'Visible','off');
% axis([0 1 0 1]);
% text(0.41,0.95, '(b)', 'FontName', 'Times New Roman', 'FontSize',9);
% Plot all fixed positions
