% %% Load the data
load('..\..\plot_data\algo\DPDQN_user_equipment.mat')
% legend_index = strings(1,length(discount));
% for i = 1:length(discount)
%     legend_index(i) = num2str(discount(i));
% end
%%

figure()
set(gcf,'Position',[100,40,420,280]);

cu1 = plot(x, CU1_ground, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
cu1.Color(4) = alpha;
hold on;
cu2 = plot(x, CU2_ground, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1, 'Markersize', 10);
cu2.Color(4) = alpha;
hold on;

Cu1 = plot(x, CU1, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Cu2 = plot(x, CU2, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Cu_limit = plot(x, CU_limit, 'Color', [0.54118, 0.16863, 0.88627], 'Linestyle', '-.', 'LineWidth',1.75, 'Markersize', 10);
hold on;

grid on
set(gca,'fontname','Times New Roman','FontSize',10);
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('Throughput(Mbps)', 'FontName', 'Times New Roman', 'FontSize', 11);
legend([Cu1 Cu2 Cu_limit],{'DU1', 'DU2', 'WDT Requirement'},...
    'FontName', 'Times New Roman', 'FontSize', 10); 

figure()
set(gcf,'Position',[100,40,420,280]);

EU1_ground = 10.^(EU1_ground/10-3);
EU2_ground = 10.^(EU2_ground/10-3);
EU1 = 10.^(EU1/10-3);
EU2 = 10.^(EU2/10-3);
EU_limit = 10.^(double(EU_limit)/10-3);

eu1 = plot(x, EU1_ground, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth', 1, 'Markersize', 10);
eu1.Color(4) = alpha;
hold on;
eu2 = plot(x, EU2_ground, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', '--', 'LineWidth', 1, 'Markersize', 10);
eu2.Color(4) = alpha;
hold on;

Eu1 = plot(x, EU1, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Eu2 = plot(x, EU2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Eu_limit = plot(x, EU_limit, 'Color', [0, 0, 0], 'Linestyle', '-.', 'LineWidth',1.75, 'Markersize', 10);
hold on;
grid on
% ylim([0 3 * 10^-6])
set(gca,'fontname','Times New Roman','FontSize',10);
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('Energy Harvesting(mJ/frame)', 'FontName', 'Times New Roman', 'FontSize', 11);
legend([Eu1 Eu2 Eu_limit],{'EU1', 'EU2', 'WET Requirement'},...
    'FontName', 'Times New Roman', 'FontSize', 10); 
% 
% subplot(titleA);
% set(titleA,'Visible','off');
% axis([0 1 0 1]);
% text(0.45,0.5, '(a)', 'FontName', 'Times New Roman', 'FontSize',14);
% 
% subplot(titleB);
% set(titleB,'Visible','off');
% axis([0 1 0 1]);
% text(0.45,0.5, '(b)', 'FontName', 'Times New Roman', 'FontSize',14);
% Plot all fixed positions
