clear all
%% Load the data
load('..\..\plot_data\algo\compare_update.mat')

%%
figure()
set(gcf,'Position',[100,40,420,280]);

beam0 = plot(x, PDQN_Beam_b, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
beam0.Color(4) = alpha;
hold on;
beam1 = plot(x, DPDQN_Beam_b, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1, 'Markersize', 10);
beam1.Color(4) = alpha;
hold on;
beam2 = plot(x, FIXEDcb_Beam_b, 'Color', [0.5549, 0.2725, 0.2725], 'Linestyle', ':', 'LineWidth',1, 'Markersize', 10);
beam2.Color(4) = alpha;
hold on;
hold on;

Beam0 = plot(x, PDQN_Beam, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Beam1 = plot(x, DPDQN_Beam, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Beam2 = plot(x, FIXEDcb_Beam, 'Color', [0.5549, 0.2725, 0.2725], 'Linestyle', ':', 'LineWidth',1.75, 'Markersize', 10);
hold on;

ylim([0 1.4])
xlim([0 400])

set(gca,'fontname','Times New Roman','FontSize',10);

grid on
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('Average Correlation Coefficient ', 'FontName', 'Times New Roman', 'FontSize', 11);
legend([Beam0 Beam1 Beam2],{'P-DQN Beam', 'DP-DQN Beam', 'Conjugate Beam'},...
    'FontName', 'Times New Roman', 'FontSize', 10); 

figure()
set(gcf,'Position',[100,40,420,280]);

classification0 = plot(x, PDQN_Classification_b, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
classification0.Color(4) = alpha;
hold on;
classification1 = plot(x, DPDQN_Classification_b, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1, 'Markersize', 10);
classification1.Color(4) = alpha;
hold on;
classification2 = plot(x, FIXEDcb_Classification_b, 'Color', [0.6980, 0.1333, 0.1333], 'Linestyle', ':', 'LineWidth',1, 'Markersize', 10);
classification2.Color(4) = alpha;
hold on;
classification3 = plot(x, RANDcb_Classification_b, 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-.', 'LineWidth',1, 'Markersize', 10);
classification3.Color(4) = alpha;
hold on;

PDQN_Classification(PDQN_Classification<=0) = 0;
DPDQN_Classification(DPDQN_Classification<=0) = 0;
DPDQNcb_Classification(FIXEDcb_Classification<=0) = 0;
RANDcb_Classification(RANDcb_Classification<=0) = 0;

Classification0 = plot(x, PDQN_Classification, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Classification1 = plot(x, DPDQN_Classification, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Classification2 = plot(x, FIXEDcb_Classification, 'Color', [0.6980, 0.1333, 0.1333], 'Linestyle', ':', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Classification3 = plot(x, RANDcb_Classification, 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-.', 'LineWidth',1.75, 'Markersize', 10);
hold on;
grid on

ylim([-0.1 1.4])
xlim([0 400])

set(gca,'fontname','Times New Roman','FontSize',10);

xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel({'Average Update in'; 'One Transmission Frame'}, 'FontName', 'Times New Roman', 'FontSize', 11);
legend([Classification0 Classification1 Classification2 Classification3],...
    {'P-DQN Classification',  'DP-DQN Classification', 'FIXED Classification' 'RAND Classification'},...
    'FontName', 'Times New Roman', 'FontSize', 10); 


% axes('Position',[0.7,0.3,0.2,0.2]); % ������ͼ ��򵥵ķ�ʽ
% classification0 = plot(x(250:300), PDQN_Classification_b(250:300), 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
% classification0.Color(4) = alpha;
% hold on;
% classification1 = plot(x(250:300), DPDQN_Classification_b(250:300), 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
% classification1.Color(4) = alpha;
% hold on;
% classification2 = plot(x(250:300), FIXEDcb_Classification_b(250:300), 'Color', [0.6980, 0.1333, 0.1333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
% classification2.Color(4) = alpha;
% hold on;
% classification3 = plot(x(250:300), RANDcb_Classification_b(250:300), 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
% classification3.Color(4) = alpha;
% hold on;
% 
% Classification0 = plot(x(250:300), PDQN_Classification(250:300), 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
% hold on;
% Classification1 = plot(x(250:300), DPDQN_Classification(250:300), 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
% hold on;
% Classification2 = plot(x(250:300), FIXEDcb_Classification(250:300), 'Color', [0.6980, 0.1333, 0.1333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
% hold on;
% Classification3 = plot(x(250:300), RANDcb_Classification(250:300), 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
% hold on;
% grid on
% 
% ylim([0 0.2])