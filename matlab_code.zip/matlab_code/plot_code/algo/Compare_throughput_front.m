
%%

load('..\..\plot_data\algo\compare_fronthaul_throughput.mat')

figure()
set(gcf,'Position',[100,40,420,280]);

throughput0 = plot(x, PDQN_throughput_b, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
throughput0.Color(4) = alpha;
hold on;
throughput1 = plot(x, DPDQN_throughput_b, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1, 'Markersize', 10);
throughput1.Color(4) = alpha;
hold on;
throughput2 = plot(x, FIXEDcb_throughput_b, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1, 'Markersize', 10);
throughput2.Color(4) = alpha;
hold on;
throughput3 = plot(x, RANDcb_throughput_b, 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-.', 'LineWidth',1, 'Markersize', 10);
throughput3.Color(4) = alpha;
hold on;

Throughput0 = plot(x, PDQN_throughput, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Throughput1 = plot(x, DPDQN_throughput, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Throughput2 = plot(x, FIXEDcb_throughput, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Throughput3 = plot(x, RANDcb_throughput, 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-.', 'LineWidth',1.75, 'Markersize', 10);
hold on;

grid on
set(gca,'fontname','Times New Roman','FontSize',10);
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('Average user throughput (Mpbs)', 'FontName', 'Times New Roman', 'FontSize', 11);
legend([Throughput0 Throughput1 Throughput2 Throughput3], ...
    {'P-DQN', 'DP-DQN', 'FIXED + CB', 'RAND + CB'}, ...
    'FontName', 'Times New Roman', 'FontSize', 10); 

figure()
set(gcf,'Position',[100,40,420,280]);

new_x = [0, 49, 99, 149, 199, 249, 299, 349, 399];
f_limit = ones(1,length(new_x)) * 25;

throughput0 = plot(x, PDQN_front_b, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
throughput0.Color(4) = alpha;
hold on;
front1 = plot(x, DPDQN_front_b, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1, 'Markersize', 10);
front1.Color(4) = alpha;
hold on;
front2 = plot(x, FIXEDcb_front_b, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1, 'Markersize', 10);
front2.Color(4) = alpha;
hold on;
front3 = plot(x, RANDcb_front_b, 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-.', 'LineWidth',1, 'Markersize', 10);
front3.Color(4) = alpha;
hold on;

Front0 = plot(x, PDQN_front, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Front1 = plot(x, DPDQN_front, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Front2 = plot(x, FIXEDcb_front, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Front3 = plot(x, RANDcb_front, 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-.', 'LineWidth',1.75, 'Markersize', 10);
hold on;

F_limit = plot(new_x, f_limit, 'Color', [0, 0, 0], 'Linestyle', '-', 'LineWidth',1.75, 'Marker', '^', 'Markersize', 4);
hold on;
grid on

xlim([0 400])
ylim([0 350]) 

set(gca,'fontname','Times New Roman','FontSize',10);

xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('Fronthaul Throughput (Mbps)', 'FontName', 'Times New Roman', 'FontSize', 11);
legend([Front0 Front1 Front2 Front3 F_limit], ...
    {'P-DQN', 'DP-DQN', 'FIXED + CB', 'RAND + CB', 'Fronthaul Capacity'}, ...
    'FontName', 'Times New Roman', 'FontSize', 10); 

