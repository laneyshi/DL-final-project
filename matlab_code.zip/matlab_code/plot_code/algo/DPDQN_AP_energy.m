
%%

load('..\..\plot_data\algo\DPDQN_AP_energy.mat')

figure()
set(gcf,'Position',[100,40,420,280]);

ap1 = plot(x, AP1_ground, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
ap1.Color(4) = alpha;
hold on;
ap2 = plot(x, AP2_ground, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1, 'Markersize', 10);
ap2.Color(4) = alpha;
hold on;
ap3 = plot(x, AP3_ground, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1, 'Markersize', 10);
ap3.Color(4) = alpha;
hold on;

Ap1 = plot(x, AP1, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Ap2 = plot(x, AP2, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Ap3 = plot(x, AP3, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1.75, 'Markersize', 10);
hold on;
single = plot(x, Single_limit, 'Color', [0, 0, 0], 'Linestyle', '-.', 'LineWidth',1.75, 'Markersize', 10);
hold on;
grid on
ylim([0 0.5])
xlim([0 400])
set(gca,'fontname','Times New Roman','FontSize',10);
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('Average Transmit Power (W)', 'FontName', 'Times New Roman', 'FontSize', 11);
legend([Ap1 Ap2 Ap3 single], ...
    {'AP1', 'AP2', 'AP3', 'Constraint'},...
    'FontName', 'Times New Roman', 'FontSize', 10); 

load('..\..\plot_data\algo\DPDQN_Max_AP.mat')

figure()
set(gcf,'Position',[100,40,420,280]);

ap1 = plot(x, AP1_ground, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
ap1.Color(4) = alpha;
hold on;
ap2 = plot(x, AP2_ground, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1, 'Markersize', 10);
ap2.Color(4) = alpha;
hold on;
ap3 = plot(x, AP3_ground, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1, 'Markersize', 10);
ap3.Color(4) = alpha;
hold on;

Ap1 = plot(x, AP1, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Ap2 = plot(x, AP2, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Ap3 = plot(x, AP3, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1.75, 'Markersize', 10);
hold on;
single = plot(x, Single_limit, 'Color', [0, 0, 0], 'Linestyle', '-.', 'LineWidth',1.75, 'Markersize', 10);
hold on;
grid on
xlim([0 400])
set(gca,'fontname','Times New Roman','FontSize',10);
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('Maximum Transmit Power (W)', 'FontName', 'Times New Roman', 'FontSize', 11);
legend([Ap1 Ap2 Ap3 single], ...
    {'AP1', 'AP2', 'AP3', 'Constraint'},...
    'FontName', 'Times New Roman', 'FontSize', 10); 

% axes('Position',[0.60,0.75,0.18,0.18]); % ������ͼ ��򵥵ķ�ʽ
% 
% ap1_cons = plot(x(200:499), AP1_ground(200:499), 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
% ap1_cons.Color(4) = alpha;
% hold on;
% ap2_cons = plot(x(200:499), AP2_ground(200:499), 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
% ap2_cons.Color(4) = alpha;
% hold on;
% ap3_cons = plot(x(200:499), AP3_ground(200:499), 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
% ap3_cons.Color(4) = alpha;
% hold on;
% Ap1s = plot(x(200:499), AP1(200:499), 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
% hold on;
% Ap2s = plot(x(200:499), AP2(200:499), 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
% hold on;
% Ap3s = plot(x(200:499), AP3(200:499), 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
% hold on;
% singles = plot(x(200:499), Single_limit(200:499), 'Color', [0, 0, 0], 'Linestyle', '-', 'LineWidth',1.5, 'Markersize', 10);
% % ylim([3.5 5.5])
% hold on;
% grid on;

% subplot(titleA);
% set(titleA,'Visible','off');
% axis([0 1 0 1]);
% text(0.45,0.5, '(a)', 'FontName', 'Times New Roman', 'FontSize',14);
% 
% subplot(titleB);
% set(titleB,'Visible','off');
% axis([0 1 0 1]);
% text(0.45,0.5, '(b)', 'FontName', 'Times New Roman', 'FontSize',14);
% Plot all fixed positions
