%% Load the data
load('..\..\plot_data\algo\compare_system_energy_reward.mat')

% legend_index = strings(1,length(discount));
% for i = 1:length(discount)
%     legend_index(i) = num2str(discount(i));
% end
%%

figure()
set(gcf,'Position',[100,40,420,280]);

energy0 = plot(x, PDQN_energy_b, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
energy0.Color(4) = alpha;
hold on;
energy1 = plot(x, DPDQN_energy_b, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1, 'Markersize', 10);
energy1.Color(4) = alpha;
hold on;
energy2 = plot(x, FIXEDcb_energy_b, 'Color', [0.6980, 0.1333, 0.1333], 'Linestyle', ':', 'LineWidth',1, 'Markersize', 10);
energy2.Color(4) = alpha;
hold on;
energy3 = plot(x, RANDcb_energy_b, 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-.', 'LineWidth',1, 'Markersize', 10);
energy3.Color(4) = alpha;
hold on;

Energy0 = plot(x, PDQN_energy, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Energy1 = plot(x, DPDQN_energy, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Energy2 = plot(x, FIXEDcb_energy, 'Color', [0.6980, 0.1333, 0.1333], 'Linestyle', ':', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Energy3 = plot(x, RANDcb_energy, 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-.', 'LineWidth',1.75, 'Markersize', 10);
hold on;
grid on

ylim([0.5 4])
xlim([0 400])
set(gca,'fontname','Times New Roman','FontSize',10);

xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('Network Energy Consumption (mJ/frame)', 'FontName', 'Times New Roman', 'FontSize', 10);
legend([Energy0 Energy1 Energy2 Energy3],{'P-DQN', 'DP-DQN', 'FIXED + CB',  'RAND + CB'},...
    'FontName', 'Times New Roman', 'FontSize', 10); 

% load('C:/Users/admin/PycharmProjects/pythonProject/matlab_code/compare_reward.mat')

figure()
set(gcf,'Position',[100,40,420,280]);

reward0 = plot(x, PDQN_reward_b , 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
reward0.Color(4) = alpha;
hold on;
reward1 = plot(x, DPDQN_reward_b , 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1, 'Markersize', 10);
reward1.Color(4) = alpha;
hold on;
reward2 = plot(x, FIXEDcb_reward_b , 'Color', [0.6980, 0.1333, 0.1333], 'Linestyle', ':', 'LineWidth',1, 'Markersize', 10);
reward2.Color(4) = alpha;
hold on;
reward3 = plot(x, RANDcb_reward_b , 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-.', 'LineWidth',1, 'Markersize', 10);
reward3.Color(4) = alpha;
hold on;

Reward0 = plot(x, PDQN_reward, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Reward1 = plot(x, DPDQN_reward , 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Reward2 = plot(x, FIXEDcb_reward , 'Color', [0.6980, 0.1333, 0.1333], 'Linestyle', ':', 'LineWidth',1.75, 'Markersize', 10);
hold on;
Reward3 = plot(x, RANDcb_reward, 'Color', [0.4117, 0.4117, 0.4117], 'Linestyle', '-.', 'LineWidth',1.75, 'Markersize', 10);
hold on;

ylim([-140 100])
xlim([0 400])

grid on
set(gca,'fontname','Times New Roman','FontSize',10);
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('Average Reward', 'FontName', 'Times New Roman', 'FontSize', 11);
legend([Reward0 Reward1 Reward2 Reward3],...
    {'P-DQN', 'DP-DQN', 'FIXED + CB',  'RAND + CB'}, 'FontName', 'Times New Roman', 'FontSize', 10); 

% subplot(titleA);
% set(titleA,'Visible','off');
% axis([0 1 0 1]);
% text(0.45,0.5, '(a)', 'FontName', 'Times New Roman', 'FontSize',14);
% 
% subplot(titleB);
% set(titleB,'Visible','off');
% axis([0 1 0 1]);
% text(0.45,0.5, '(b)', 'FontName', 'Times New Roman', 'FontSize',14);
% Plot all fixed positions
