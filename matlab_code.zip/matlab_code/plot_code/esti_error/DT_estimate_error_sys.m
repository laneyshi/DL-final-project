clear all
%% Load the data
load('..\..\plot_data\esti_error\esti_error_system_energy.mat')

legend_index = strings(1,length(esti_error));
for i = 1:length(esti_error)
    legend_index(i) = num2str(esti_error(i));
end
%%
figure()
set(gcf,'Position',[100,40,420,280]);


error0 = plot(x, TDerror0, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
error0.Color(4) = alpha;
hold on;
error1 = plot(x, TDerror1, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1, 'Markersize', 10);
error1.Color(4) = alpha;
hold on;
error2 = plot(x, TDerror2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1, 'Markersize', 10);
error2.Color(4) = alpha;
hold on;
% error3 = plot(x, TDerror3, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
% error3.Color(4) = alpha;
hold on;


energy0 = plot(x, Energy0, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
energy1 = plot(x, Energy1, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
energy2 = plot(x, Energy2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1.75, 'Markersize', 10);
hold on;
% energy3 = plot(x, Energy3, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
% hold on;
grid on

ylim([0 2.5])
xlim([0 400])

set(gca,'fontname','Times New Roman','FontSize',10);
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('Network Energy Consumption (mJ/frame)', 'FontName', 'Times New Roman', 'FontSize', 11);
h = legend([energy0 energy1 energy2], ...
    {['Without DT '], ['Pefect DT'], ['Imperfect DT']},...
    'FontName', 'Times New Roman', 'FontSize', 10 ,'interpreter','latex','Location','southeast'); 
set(h,'FontName','Times New Roman','FontSize',10,'FontWeight','normal')

load('..\..\plot_data\esti_error\esti_error_system_reward.mat')

figure()
set(gcf,'Position',[100,40,420,280]);

error0 = plot(x, TDerror0, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
error0.Color(4) = alpha;
hold on;
errot1 = plot(x, TDerror1, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1, 'Markersize', 10);
errot1.Color(4) = alpha;
hold on;
error2 = plot(x, TDerror2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1, 'Markersize', 10);
error2.Color(4) = alpha;
hold on;
% error3 = plot(x, TDerror3, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-', 'LineWidth',1, 'Markersize', 10);
% error3.Color(4) = alpha;
% hold on;
hold on

reward0 = plot(x, Reward0, 'Color', [0.13333, 0.5451, 0.13333], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
hold on;
reward1 = plot(x, Reward1, 'Color', [0.2549, 0.41176, 0.88235], 'Linestyle', '--', 'LineWidth',1.75, 'Markersize', 10);
hold on;
reward2 = plot(x, Reward2, 'Color', [0.69804, 0.13333, 0.13333], 'Linestyle', ':', 'LineWidth',1.75, 'Markersize', 10);
hold on;
% reward3 = plot(x, Reward3, 'Color', [0.80392, 0.52157, 0.24706], 'Linestyle', '-', 'LineWidth',1.75, 'Markersize', 10);
% hold on;
grid on

xlim([0 400])

set(gca,'fontname','Times New Roman','FontSize',10);
xlabel('Episode', 'FontName', 'Times New Roman', 'FontSize', 11);
ylabel('Average Reward', 'FontName', 'Times New Roman', 'FontSize', 11);
h = legend([reward0 reward1 reward2], ...
    {['Without DT '], ['Pefect DT'],['Imperfect DT']},...
    'FontName', 'Times New Roman', 'FontSize', 10,'interpreter','latex','Location','southeast'); 
set(h,'FontName','Times New Roman','FontSize',10,'FontWeight','normal')
